//
//  Text+Extension.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/26/21.
//

import Foundation
import SwiftUI

extension View {
    
    func customText(Text text: String,
                    FontName fontName: Enum_FontName = .System_regular,
                    FontSize fontSize: CGFloat = 14,
                    TextColor txtColor: Color = .black,
                    Alignment alignment: Alignment = .leading,
                    CornerRadius cornerRadius: CGFloat = 0,
                    BorderColor borderColor: Color = .clear,
                    BorderWidth borderWidth: CGFloat = 0) -> some View {
        
        let txt = Text(text)
        
        return txt
            .setFont(FontName: fontName.rawValue, FontSize: fontSize)
            .foregroundColor(txtColor)
            .overlay(RoundedRectangle(cornerRadius: cornerRadius).stroke(borderColor, lineWidth: borderWidth))
            .frame(minWidth: 0, maxWidth: .infinity, alignment: alignment)
    }
}
