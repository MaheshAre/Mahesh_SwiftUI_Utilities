//
//  SideMenuView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/10/21.
//

import SwiftUI

/*
 
 Usage:
 
 struct SideMenuView: View {
     
     @State var menuOpen: Bool = false
     
     var body: some View {
         
         
         ZStack(alignment: .top, content: {
            
             if !self.menuOpen {
                 HStack {

                     Button(action: {
                         self.openMenu()
                     }, label: {
                         Text("Open")
                             .padding()
                         Spacer()
                     })
                 }
                                 
             }
             SideMenu(width: screenWidth-120,
                      isOpen: self.menuOpen,
                      menuClose: self.openMenu)
         })
         .navigationTitle("Side Menu")
         .navigationBarTitleDisplayMode(.inline)
     }
     
     func openMenu() {
         self.menuOpen.toggle()
     }
 }
 
 
 func openMenu() {
     self.menuOpen.toggle()
 }
 
 * Create Menu Content View struct.
 
 struct MenuContent: View {
     
     @State var isLoggedOut = false
     
     @ObservedObject var vmMenuItems = VMMenuItem()
             
     var body: some View {
         
         List {
             
             ForEach(Array(zip(1..., self.vmMenuItems.menu_items)), id: \.1.id) { index, data in
                 
                 if index == 1 {
                     
                     ZStack {
                         NavigationLink(destination: Text("My Profile")) {
                             
                         }
                         .opacity(0)
                         MenuItemView(menuItem: data)
                         
                     }
                     
                 }else if index == 2 {
                     
                     ZStack {
                         NavigationLink(destination: Text("Post Request")) {
                             
                         }
                         .opacity(0)
                         MenuItemView(menuItem: data)
                     }
                     
                 }
            }
        }
    }
}
 
 
 */

struct SideMenu: View {
    
    let width: CGFloat
    let isOpen: Bool
    let menuClose: () -> Void
    
    var body: some View {
        
        ZStack {
            GeometryReader { _ in
                EmptyView()
            }
            .background(Color.gray.opacity(0.3))
            .opacity(self.isOpen ? 1.0 : 0.0)
            .animation(Animation.easeIn.delay(0.25))
            .onTapGesture {
                self.menuClose()
            }
            
            HStack {
                MenuContent() // Menu ContentView
                    .frame(width: self.width)
                    .background(Color.white)
                    .offset(x: self.isOpen ? 0 : -self.width)
                    .animation(.default)
                
                Spacer()
            
            }
        }
    }
}

//struct SideMenu_Previews: PreviewProvider {
//    static var previews: some View {
//        SideMenu()
//    }
//}


struct MenuItemView: View {
    
    var menuItem: MenuItemStructure
    
    var body: some View {
        
        HStack {
            
            menuItem.img ?? Image("")
                .set_ImageProperties(ContentMode: .fit, Width: 25, Height: 25, Corner: 0) as? Image
            Text(menuItem.title!)
                .default_MenButtonStyle()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        
    }
}

struct MenuItem_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemView(menuItem: MenuItemStructure(id: UUID(), title: "", img: Image.img_placeHolder))
    }
}

////MARK:- ViewModel
//
//class VMMenuItem:NSObject, ObservableObject {
//
//    @Published var id = UUID()
//    @Published var menu_items = [MenuItemStructure]()
//
//    override init() {
//
//        self.menu_items = [MenuItemStructure(title: "My Profile", img: Image.img_placeHolder),
//                           MenuItemStructure(title: "Posts", img: Image.img_placeHolder),
//                           MenuItemStructure(title: "Logout", img: Image.img_placeHolder)]
//    }
//
//}
//
////MARK:- Model
//struct MenuItemStructure: Identifiable {
//
//    var id = UUID()
//    var title: String?
//    var img: Image?
//}
