//
//  VMInvoice.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/26/21.
//

import Foundation
import Combine

class VMInvoice: ObservableObject {
    
    @Published var model_invoice = ModelInvoice()
    @Published var params = ParamsInvoice()
    @Published var invoiceArray = [InvoiceResponse]()
    
    // Search From Array
    @Published var searchText = ""
    var filteredInvoiceArray = [InvoiceResponse]()
    var publisher: AnyCancellable?
    
    init() {
        
        self.publisher = $searchText
            .receive(on: RunLoop.main)
            .sink(receiveValue: { [self] (str) in
                if !self.searchText.isEmpty {
                    self.filteredInvoiceArray = self.invoiceArray.filter{ ($0.ContactName?.localizedCaseInsensitiveContains(searchText))! }
                } else {
                    self.filteredInvoiceArray = self.invoiceArray
                }
            })
    }
    
    func service_invoice() {
        
        let parameters = ["count": "50", "Start": "0", "ToDate": "", "type": "Invoices", "FromDate": "", "ContactId":"", "Search": ""]
        
        NetworkManager.shared.createRequest(apiStr: .invoice, method: .get, params: parameters, headerContentType: .formurlencoded, isShowLoader: true) { (response, error) in
            
            if let error = error {
                CustomAlertController.showAlertController(title: "Error", message: error, actionTitle: "Ok", onCompletion: nil)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelInvoice.self, from: response!.data!)
                    self.model_invoice = jsonData
                    if let array = jsonData.Result {
                        self.invoiceArray = array
                        self.filteredInvoiceArray = array
                    }
                }catch {
                    print(error)
                }
            }
        }
        
    }
}

struct ParamsInvoice {
    
    var count = ""
    var Start = ""
    var ToDate = ""
    var type = "Invoices"
    var FromDate = ""
    var ContactId = ""
    var Search = ""
    
}
