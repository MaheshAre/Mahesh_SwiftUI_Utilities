//
//  CollectionView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/26/21.
//

import SwiftUI

struct CollectionView: View {
    
    
    //    private var symbols = ["keyboard", "hifispeaker.fill", "printer.fill", "tv.fill", "desktopcomputer", "headphones", "tv.music.note", "mic", "plus.bubble", "video"]
    
    //    private var colors: [Color] = [.yellow, .purple, .green]
    
    var body: some View {
        
        VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 15, content: {
            
            HorizontalGridView(rowsCount: 1)
            VerticalGridView(columnCount: 3)
        })
        .navigationTitle("GridView")
        
    }
    
}

struct CollectionView_Previews: PreviewProvider {
    static var previews: some View {
        CollectionView()
    }
}


struct HorizontalGridView: View {
    
    @State var rowsCount: Int
    
    var body: some View {
        
        let rows = Array(repeating: GridItem(.flexible()), count: self.rowsCount)
        
        VStack {
            
            Text("Horizontal Grid")
                .font(.title)
            
            ScrollView(.horizontal, showsIndicators: false, content: {
                
                LazyHGrid(rows: rows, alignment: .center) {
                    
                    ForEach(0..<15) { i in
                        
                        ZStack {
                            
                            Rectangle()
                                .frame(width: 100, height: 100, alignment: .center)
                                .foregroundColor(.gray)
                            
                            Text("\(i)")
                                .foregroundColor(Color.white)
                                .font(.title2)
                        }
                        .cornerRadius(15)
//                        .padding()
                    }
                    
                }
                
            })
            .setShadow(CornerRadius: 10, ShadowColor: nil)
            .frame(maxWidth: screenWidth - 30, maxHeight: 150, alignment: .topLeading)
        }
    }
}

struct VerticalGridView: View {
    
    @State var columnCount: Int
    
    var body: some View {
        
        let columns = Array(repeating: GridItem(.flexible()), count: self.columnCount)
        
        VStack {
            
            Text("Vertical Grid")
                .font(.title)
            
            ScrollView(/*@START_MENU_TOKEN@*/.vertical/*@END_MENU_TOKEN@*/, showsIndicators: false, content: {
                
                LazyVGrid(columns: columns, alignment: .center) {
                    
                    ForEach(0..<15) { i in
                        
                        ZStack {
                            
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundColor(.white)
                                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, minHeight: 100, maxHeight: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            Text("\(i)")
                                .foregroundColor(Color.black)
                                .font(.title2)
                            
                        }
                        .modifier(SetCornerRadius(width: 1.5, color: .gray, cornerRadius: 15))
                        
                    }
                    
                }
//                .padding()
                
            })
            .setShadow(CornerRadius: 10, ShadowColor: nil)
            .frame(maxWidth: screenWidth - 30, maxHeight: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .topLeading)
        }
    }
}
