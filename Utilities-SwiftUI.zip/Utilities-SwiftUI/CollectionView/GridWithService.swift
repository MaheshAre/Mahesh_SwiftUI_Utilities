//
//  GridWithService.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/1/21.
//

import SwiftUI
import SDWebImageSwiftUI

struct GridWithService: View {
    
    @ObservedObject var vmGet = VMGet()
    
    var columns = Array(repeating: GridItem(.flexible()), count: 2)
    
    var body: some View {
        
        ScrollView(.vertical, showsIndicators: false, content: {
            
            LazyVGrid(columns: self.columns, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, content: {
                
                ForEach(Array(zip(1..., self.vmGet.data)), id: \.1.id) { number, item in
                    
                    
                    VStack(alignment: .leading, spacing: 3, content: {
                        
                        HStack(alignment: .center, spacing: 3, content: {
                            
                            Spacer()
                            WebImage(url: URL(string: item.avatar ?? ""))
                                .placeholder(Image.img_placeHolder)
                                .indicator(.activity)
                                .cornerRadius(15)
                            Spacer()
                        })
                        
                        HStack {
                            Text("Emp ID: ")
                                .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 15)
                            Text("\(item.id ?? 0)")
                                .setFont(FontName: Enum_FontName.System_regular.rawValue, FontSize: 15)
                            
                            Spacer()
                        }
                        HStack {
                            Text("First Name: ")
                                .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 15)
                            Text(item.first_name ?? "NA")
                                .setFont(FontName: Enum_FontName.System_regular.rawValue, FontSize: 15)
                        }
                        HStack {
                            Text("Last Name: ")
                                .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 15)
                            Text(item.last_name ?? "NA")
                                .setFont(FontName: Enum_FontName.System_regular.rawValue, FontSize: 15)
                        }
                        
                        HStack {
                            Text("Email: ")
                                .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 15)
                            Text(item.email ?? "NA")
                                .setFont(FontName: Enum_FontName.System_regular.rawValue, FontSize: 15)
                        }
                        
                        
                    })
                    .setShadow(CornerRadius: 10, ShadowColor: .gray, ShadowRadius: 5)
                    .padding(5)
                    .onTapGesture {
                        print(item)
                        
                    }
                    
                }
                
                
            })
            
        }).navigationTitle("Grid with Service")
        .setShadow(CornerRadius: 10, ShadowColor: .gray, ShadowRadius: 2)
        .padding(8)
        .onAppear() {
            self.vmGet.servicGETRequest()
        }
        
        
    }
}

struct GridWithService_Previews: PreviewProvider {
    static var previews: some View {
        GridWithService()
    }
}
