//
//  Enums.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/18/21.
//

import Foundation
import SwiftUI

enum Enum_FontName: String {
    
    // System Font Name SFUIText
    case System_regular = "SFUIText"
    case System_ultraLight = "SFUIText-UltraLight"
    case System_thin = "SFUIText-UltraLight-Thin"
    case System_light = "SFUIText-UltraLight-Light"
    case System_medium = "SFUIText-Medium"
    case System_semibold = "SFUIText-Semibold"
    case System_bold = "SFUIText-Bold"
    case System_heavy = "SFUIText-Heavy"
    case System_black = "SFUIText-Black"
    
    case OpenSans_light = "Open Sans Light"
    case OpenSans_regular = "Open Sans Regular"
    case OpenSans_italic = "Open Sans Italic"
    case OpenSans_semibold = "Open Sans Semibold"
    case OpenSans_bold = "Open Sans Bold"
    case OpenSans_extraBold = "Open Sans Extrabold"
    
    
    case HelveticaNeue_regular = "HelveticaNeue-Regular"
    case HelveticaNeue_bold = "HelveticaNeue-Bold"
    case HelveticaNeue_italic = "HelveticaNeue-Italic"
    case HelveticaNeue_light = "Helvetica Neue Light"
    case HelveticaNeue_medium = "Helvetica Neue Medium"
    
    
    case Verdana = "Verdana"
    case Verdana_bold = "Verdana Bold"
    case Verdana_boldItalic = "Verdana Bold Italic"
    case Verdana_italic = "Verdana Italic"
    
}

enum Enum_CommingFromView {
    
    case loginView
    case registrationView
    
}
