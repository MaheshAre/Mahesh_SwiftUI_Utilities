//
//  GPSLocation.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/10/21.
//



import Foundation
import CoreLocation
import Combine
import SwiftUI

//MARK:- Get Address

/*
 
 Usage:
 
 @ObservedObject var locationManager = LocationManager()
 
 Text("\(self.locationManager.addressStruct?.formattedAddress ?? "Address")")
 
 
 */


class LocationManager: NSObject, ObservableObject {
    
    override init() {
        
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        
    }
    
    init(IsUpdateCurrentLocation update: Bool) {
        
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization()
        
        if update {
            self.locationManager.startUpdatingLocation()
        }else {
            self.locationManager.stopUpdatingLocation()
        }
        
    }
    
    
    init(Coordinates coordinates: CLLocationCoordinate2D) {
        super.init()
        
        LocationManager.convertLatLongToAddress(latitude: coordinates.latitude, longitude: coordinates.longitude, onCompletion: { addressStruct in
            self.addressStruct = addressStruct
            self.lat = addressStruct.latitude
            self.long = addressStruct.longitude
            self.coordinate = addressStruct.coordinate
        })
    }
    
    @Published var locationStatus: CLAuthorizationStatus? {
        willSet {
            objectWillChange.send()
        }
    }
    
//    @Published var lastLocation: CLLocation? {
//        willSet {
//            objectWillChange.send()
//        }
//    }
    
    @Published var coordinate: CLLocationCoordinate2D? {
        willSet {
            objectWillChange.send()
        }
    }
    
    @Published var addressStruct: AddressStruct? {
        willSet {
            objectWillChange.send()
        }
    }
    
    @Published var lat: Double? {
        willSet {
            objectWillChange.send()
        }
    }
    
    @Published var long: Double? {
        willSet {
            objectWillChange.send()
        }
    }
    
    var statusString: String {
        guard let status = locationStatus else {
            return "unknown"
        }
        
        switch status {
        case .notDetermined: return "notDetermined"
        case .authorizedWhenInUse: return "authorizedWhenInUse"
        case .authorizedAlways: return "authorizedAlways"
        case .restricted: return "restricted"
        case .denied: return "denied"
        default: return "unknown"
        }
        
    }
    
    let objectWillChange = PassthroughSubject<Void, Never>()
    
    private let locationManager = CLLocationManager()
    
    
    static func convertLatLongToAddress(latitude:Double,longitude:Double, onCompletion: @escaping(_ addressStruct: AddressStruct)->Void) {
        
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: latitude, longitude: longitude)
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
            
            guard let placeMark = placemarks?.first else {
                debugPrint("PlaceMarks error")
                return
            }
            onCompletion(AddressStruct(with: placeMark))
            
        })
        
    }
    
}

extension LocationManager: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        self.locationStatus = status
        //        print(#function, statusString)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
//        self.lastLocation = location
        
        self.lat = location.coordinate.latitude
        self.long = location.coordinate.longitude
        
        self.coordinate = location.coordinate
        
        LocationManager.convertLatLongToAddress(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude, onCompletion: { addressStruct in
            self.addressStruct = addressStruct
        })
        self.locationManager.stopUpdatingLocation()
        //        print(#function, location)
    }
    
}


class AddressStruct: NSObject {
    
    var name: String = ""           // eg. Apple Inc.
    var streetName: String = ""      // eg. Infinite Loop
    var streetNumber: String = ""    // eg. 1
    var city: String = ""            // eg. Cupertino
    var state: String = ""          // eg. CA
    var zipCode: String = ""         // eg. 95014
    var country: String = ""        // eg. United States
    var isoCountryCode: String = ""  // eg. US
    var latitude = 0.0
    var longitude = 0.0
    var coordinate = CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
    
    var formattedAddress: String {
        
        var text = ""
        var data_array = [name, streetNumber, city, state, zipCode, country]
        
        if name.compareIngoreCase(SecondStr: streetName) == false {
            data_array.insert(streetName, at: 2)
        }
        
        //[name, streetNumber, streetName, city, state, zipCode, country]
        //        print("Address")
        for (index, obj) in data_array.enumerated() {
            //            print("name ->", name)
            //            print("Street number ->", streetNumber)
            //            print("Street name ->", streetName)
            
            if obj != "" {
                if index == 0 {
                    text = obj
                }else  {
                    text += ", " + obj
                }
                
            }
        }
        
        return text
    }
    
    override init() {
        
    }
    
    // Handle optionals as needed
    init(with placemark: CLPlacemark) {
        
        self.name           = placemark.name ?? ""
        self.streetName     = placemark.thoroughfare ?? ""
        self.streetNumber   = placemark.subThoroughfare ?? ""
        self.city           = placemark.locality ?? ""
        self.state          = placemark.administrativeArea ?? ""
        self.zipCode        = placemark.postalCode ?? ""
        self.country        = placemark.country ?? ""
        self.isoCountryCode = placemark.isoCountryCode ?? ""
        self.latitude = placemark.location?.coordinate.latitude ?? 100.0
        self.longitude = placemark.location?.coordinate.longitude ?? 100.0
        self.coordinate = CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude)
    }
}

extension CLLocationCoordinate2D: Identifiable {
    
    public var id: String {
        "ID"
    }
    
    public var coordinateStr: String {
        "\(latitude)-\(longitude)"
    }
}

extension Image {
    
    static var icon_search: Image {
        return UIImage(named: "search")!.toImage()
    }
    
    static var icon_currentLocation: Self {
        return UIImage(named: "currentLocation.png")!.toImage()
    }
    
}

//extension UIImage {
//
//    func toImage() -> Image {
//        return Image(uiImage: self)
//    }
//}
